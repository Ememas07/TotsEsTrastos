/*
 Navicat Premium Dump SQL

 Source Server         : portatil2
 Source Server Type    : MariaDB
 Source Server Version : 100241 (10.2.41-MariaDB-1:10.2.41+maria~bionic)
 Source Host           : 192.168.1.115:33700
 Source Schema         : Pra2nTri

 Target Server Type    : MariaDB
 Target Server Version : 100241 (10.2.41-MariaDB-1:10.2.41+maria~bionic)
 File Encoding         : 65001

 Date: 09/04/2026 17:25:30
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for categoria
-- ----------------------------
DROP TABLE IF EXISTS `categoria`;
CREATE TABLE `categoria`  (
  `idCategoria` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `nivell` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `descripcio` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  PRIMARY KEY (`idCategoria`, `nom`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_spanish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of categoria
-- ----------------------------

-- ----------------------------
-- Table structure for equip
-- ----------------------------
DROP TABLE IF EXISTS `equip`;
CREATE TABLE `equip`  (
  `idEquip` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NULL DEFAULT NULL,
  `patrocinador` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NULL DEFAULT NULL,
  `respresentant` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`idEquip`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_spanish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of equip
-- ----------------------------

-- ----------------------------
-- Table structure for esport
-- ----------------------------
DROP TABLE IF EXISTS `esport`;
CREATE TABLE `esport`  (
  `idEsport` int(11) NOT NULL AUTO_INCREMENT,
  `Nom` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `Descripcio` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  PRIMARY KEY (`idEsport`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_spanish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of esport
-- ----------------------------

-- ----------------------------
-- Table structure for format
-- ----------------------------
DROP TABLE IF EXISTS `format`;
CREATE TABLE `format`  (
  `idFormat` int(11) NOT NULL AUTO_INCREMENT,
  `Nom` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `Descripcio` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  PRIMARY KEY (`idFormat`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_spanish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of format
-- ----------------------------

-- ----------------------------
-- Table structure for jugador
-- ----------------------------
DROP TABLE IF EXISTS `jugador`;
CREATE TABLE `jugador`  (
  `idJugador` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `llinatge1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `llinatge2` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NULL DEFAULT NULL,
  `dni` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `rol` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  PRIMARY KEY (`idJugador`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_spanish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of jugador
-- ----------------------------

-- ----------------------------
-- Table structure for lliga
-- ----------------------------
DROP TABLE IF EXISTS `lliga`;
CREATE TABLE `lliga`  (
  `idLliga` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `idCategoria` int(11) NOT NULL,
  `idEsport` int(11) NOT NULL,
  `idFormat` int(11) NOT NULL,
  `idReglament` int(11) NOT NULL,
  `patrocinador` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `nombreParticipants` int(11) NOT NULL,
  `tipusParticipants` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  PRIMARY KEY (`idLliga`, `nom`, `idCategoria`, `idEsport`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_spanish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of lliga
-- ----------------------------

-- ----------------------------
-- Table structure for partit
-- ----------------------------
DROP TABLE IF EXISTS `partit`;
CREATE TABLE `partit`  (
  `idPartit` int(11) NOT NULL AUTO_INCREMENT,
  `data` datetime NOT NULL,
  `durada` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `resultat` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  PRIMARY KEY (`idPartit`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_spanish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of partit
-- ----------------------------
INSERT INTO `partit` VALUES (1, '2026-04-23 16:44:09', '180m', '2-1');

-- ----------------------------
-- Table structure for partitJugador
-- ----------------------------
DROP TABLE IF EXISTS `partitJugador`;
CREATE TABLE `partitJugador`  (
  `idPartit` int(11) NOT NULL,
  `idJugador` int(11) NOT NULL,
  PRIMARY KEY (`idPartit`, `idJugador`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_spanish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of partitJugador
-- ----------------------------

-- ----------------------------
-- Table structure for reglament
-- ----------------------------
DROP TABLE IF EXISTS `reglament`;
CREATE TABLE `reglament`  (
  `idReglament` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  PRIMARY KEY (`idReglament`, `nom`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_spanish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of reglament
-- ----------------------------

-- ----------------------------
-- Table structure for temporada
-- ----------------------------
DROP TABLE IF EXISTS `temporada`;
CREATE TABLE `temporada`  (
  `idTemporada` int(11) NOT NULL AUTO_INCREMENT,
  `any` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `idLliga` int(11) NOT NULL,
  `guanyador` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`idTemporada`, `any`, `idLliga`) USING BTREE,
  INDEX `any`(`any`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_spanish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of temporada
-- ----------------------------

-- ----------------------------
-- Table structure for temporadaPartit
-- ----------------------------
DROP TABLE IF EXISTS `temporadaPartit`;
CREATE TABLE `temporadaPartit`  (
  `idTemporada` int(11) NOT NULL,
  `idPartit` int(11) NOT NULL,
  PRIMARY KEY (`idTemporada`, `idPartit`) USING BTREE,
  CONSTRAINT `temporadapartit_ibfk_1` FOREIGN KEY (`idTemporada`) REFERENCES `temporada` (`idTemporada`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_spanish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of temporadaPartit
-- ----------------------------

SET FOREIGN_KEY_CHECKS = 1;
