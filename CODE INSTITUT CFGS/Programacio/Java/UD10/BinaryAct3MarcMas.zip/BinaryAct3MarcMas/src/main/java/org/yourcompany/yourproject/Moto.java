/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.yourcompany.yourproject;

/**
 *
 * @author Marc Mas
 */
public class Moto {

    String matricula;
    float cubicatge;

    public Moto(String matricula, float cubicatge) {
        this.matricula = matricula;
        this.cubicatge = cubicatge;
    }

}
