/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.yourcompany.yourproject;

/**
 *
 * @author Marc Mas
 */
public class Cotxe {

    public enum MarcaCotxe {
        PORSCHE, ASTON_MARTIN, RENAULT, BMW, DACIA
    };
    MarcaCotxe marca;
    String model;
    float cubicatge;

    public Cotxe(MarcaCotxe marca, String model, float cubicatge) {
        this.marca = marca;
        this.model = model;
        this.cubicatge = cubicatge;
    }

}
