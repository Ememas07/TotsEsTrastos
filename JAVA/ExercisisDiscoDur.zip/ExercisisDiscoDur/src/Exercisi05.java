
import javax.swing.JOptionPane;
public class Exercisi05 {
	public static void main(String[] args) {
	System.out.println("Computació de l'àrea d'un cercle");
	String radi = JOptionPane.showInputDialog("Radi?");
	double radi2 = Double.parseDouble(radi);
	System.out.println(Math.pow(radi2,2)*Math.PI);
	
		
	
	
	
	
	
	
	}
	
}



































