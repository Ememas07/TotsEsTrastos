import javax.swing.JOptionPane;

public class Exercisi09 {
	public static void main(String[] args) {
	String optionPaneInput = JOptionPane.showInputDialog("Quin és el teu preu");
	Float inputInteger =Float.parseFloat(optionPaneInput);
	Double preuAmbIVA = inputInteger*1.21;
	System.out.println("El teu preu amb IVA és "+preuAmbIVA);
	
	
	
	
	
		
		
		
	
	
	
	
	
	
	}
	
}



































