import javax.swing.JOptionPane;

public class Exercisi13 {
	public static void main(String[] args) {
	String ventes = JOptionPane.showInputDialog("Número de ventes");
	int numeroVentes = Integer.parseInt(ventes);
	int contador = 1;
	float acumulat = 0;
	System.out.println("Ha seleccionat "+ventes +" ventes");
	
	
	while(contador <=numeroVentes) {
	String venta=JOptionPane.showInputDialog("Està fent la venta " +contador);
	float ventaInt=Float.parseFloat(venta);
	acumulat = acumulat+ventaInt;
	System.out.println("Ara mateix du un total de "+acumulat);
	contador++;
	if(contador> numeroVentes){
	System.out.println("El total és de "+acumulat);
	}
	}
	
	
	
	
	
		
		
		
	
	
	
	
	
	
	}
	
}



































