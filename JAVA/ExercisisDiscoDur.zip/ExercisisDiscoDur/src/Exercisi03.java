
public class Exercisi03 {

	public static void main(String[] args) {
	String nom = "Josep"	;
	System.out.print("Benvingut " +nom);
			
			
	}
	
}



































