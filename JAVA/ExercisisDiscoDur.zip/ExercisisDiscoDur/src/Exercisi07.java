import javax.swing.JOptionPane;

public class Exercisi07 {
	public static void main(String[] args) {
	String num1 = JOptionPane.showInputDialog("Introdueix un codi ASCII");
	int codi= Integer.parseInt(num1);
	char carac = (char)codi;
	System.out.println(carac);
	
	
	
		
		
		
	
	
	
	
	
	
	}
	
}



































