

import javax.swing.JOptionPane;;
public class Exercisi04 {
	public static void main(String[] args) {
	String nom =JOptionPane.showInputDialog("Com te noms?");
	System.out.print("Benvingut " +nom);
	}
	
}



































