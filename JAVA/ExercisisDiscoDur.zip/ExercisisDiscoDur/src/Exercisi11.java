

public class Exercisi11 {
	public static void main(String[] args) {

	for (int numero = 0;numero <=100;numero++) {
		System.out.println(numero);
	}
	
	
	
	
	
		
		
		
	
	
	
	
	
	
	}
	
}



































