

import javax.swing.JOptionPane;


public class Exercisi08 {
	public static void main(String[] args) {
	String optionPaneInput = JOptionPane.showInputDialog("Introdueix un codi ASCII");
	char caracter=optionPaneInput.charAt(0);
	int ascii = caracter;
	System.out.println("La representació ascii de ("+optionPaneInput +") és (" +ascii +")");

	
	
		
		
		
	
	
	
	
	
	
	}
	
}



































