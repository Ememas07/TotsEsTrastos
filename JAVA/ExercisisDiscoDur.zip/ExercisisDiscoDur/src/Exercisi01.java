
public class Exercisi01 {

	public static void main(String[] args) {

	int n1 = 14;
	int n2 = 3;
	System.out.print("La suma es ");
	System.out.println(n1 + n2);
	System.out.print("La resta es ");
	System.out.println(n1 - n2);
	System.out.print("La multiplicación es ");
	System.out.println(n1 * n2);
	System.out.print("La división es ");
	System.out.println(n1 / n2);
	System.out.print("El resto es  ");
	System.out.println(n1 % n2);
	
	
	System.out.print("aixo no te bot de linea");
	System.out.print("aixo si");
	System.out.print("aqui si");
	
	
	
	
	
	
	}
	

}
